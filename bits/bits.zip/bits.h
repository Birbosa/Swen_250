// SWEN-250
// Larry Kiser December 5, 2023 version 1.0

// functions in bits.c
void shift_value( unsigned int *p_value, int shift ) ;
void set_bit( unsigned int *p_value, unsigned int position ) ;
void flip_all( unsigned int *p_value ) ;
void clear_bit( unsigned int *p_value, unsigned int position ) ;
