// C pointers light Practice Practicum
// SWEN-250
// Larry Kiser Nov. 22, 2015

// cpractice2 functions
char *get_pointer_at_position( char *pstring, int position ) ;
int *get_y_values( int *px, int m, int b, int number_of_x_values ) ;
int get_sum_and_free_space( int *py, int number_of_y_values ) ;
int same_array( int *pfirst, int *psecond ) ;
int fix_bad_code( char *pstring ) ;
int bool_flip_flop() ;
