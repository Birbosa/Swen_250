// unit_tests.h
// L. Kiser Oct. 28, 2015

// the main unit test
extern int test( void ) ;

// boolean assert function for unit testing
extern int assert( int testresult, char error_message[], ... ) ;
