// C pointers final practicum 
// SWEN-250 Fall 2024 Term 2241

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "pfinal.h"
#include "unit_tests.h"

// Return a NULL pointer if start_letter is not 'a' through 'z'.
// Return a NULL pointer if the number_of_letters is less than or equal to zero.
//
// If both parameters are valid create a string containing 
// successive letters starting with the lower case start_letter.
// The length of the string is specified by number_of_letters.
//
// You are required to malloc exactly the smallest valid
// string to hold the letters. You return this string.
//
// If you get to 'z' and you still have letters to add wrap
// around to the letter 'a'.
// Examples:
// start_letter == 'c' ; number_of_letters == 5 ; string == "cdefg"
// start_letter == 'y' ; number_of_letters == 4 ; string == "yzab"
// return this string from this function
// 
// Parameters:
//		start_letter is a letter from 'a' through 'z' inclusive.
//		number_of_letters is how many letters are in the string you create.
char *make_string_of_letters( char start_letter, int number_of_letters )
{
	// Your code here -- be sure to free pstring as described above!


	return BOGUS_POINTER ;		// FIX THIS!!
}


// Counts the number of letter grades in the passed array of integer grades.
// Returns 0 if the grade_count is <= 0.
// Returns 0 if p_status is a NULL pointer.
// Returns 0 if the p_grades pointer is NULL.
// Returns 1 if all three parameters are valid as described above.

// A grades are 90 through 100
// B grades are 80 through 89
// C grades are 70 through 79
// D grades are 60 through 69
// F grades are 0 through 59
// NOTE -- you can assume that all integer grades in the p_grades array  are 0 through 100.
// TIP -- initialize the p_status structure to have 0 counts.
int count_grades( int *p_grades, int grade_count, struct grade_stats *p_stats ) 
{
	// your code here

	return 9 ;		// bogus -- fix this!
}

// Search the p_input string for a number.
// If one is found convert it to an integer.
// Return that integer using the p_number_found.
// Return 1 from this function to indicate success.
// NOTE -- you can assume that p_input and p_number_found
//         are valid pointers!
//
// If no number is found return 0 from this function.
//
// You are allowed to use standard C string and conversion
// functions like atoi() and isdigit().
// Examples:
// "abdX8ZZ" return 8 and success
// "123" returns 123 and success
// "" returns failure
//
int extract_number( char *p_input, int *p_number_found ) 
{
	// your code here


	return -1 ;		// bogus -- fix this!
}


// This function is implemented incorrectly. You need to correct it.
// When fixed it returns 1 if there are any digits (0 through 9) anywhere in the passed string.
// If there are no digits it returns 0.
// It also returns 0 if the passed string pointer is NULL or if the string points to an empty string.
// You can re-write this code completely if you prefer.
int fix_bad_code( char *pstring )
{
    int result = 1 ;    // is this a good choice for initialization?

    // Fix this next line so it correctly returns 0 if the passed pointer is NULL or
    // if the pointer points to an empty string.
    if ( ( !( pstring = NULL ) ) || *pstring == '\n'  )
        return result + 2 ;

    // does this loop work correctly?
    while ( *pstring == '\0' )
        if ( isdigit( *pstring++ ) )    // isdigit returns true if the passed character is a number 0 through 9
            result = 1 ;

    return result + 7 ;
}

